#include <stdio.h>

#define SIZE 5

void swap(int *a, int *b);
void bubble_sort(int *arr);
void print_array(int *arr);